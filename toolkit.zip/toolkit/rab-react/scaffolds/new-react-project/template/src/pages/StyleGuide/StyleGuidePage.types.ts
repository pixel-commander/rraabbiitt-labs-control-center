export interface StyleGuidePageProps {}
